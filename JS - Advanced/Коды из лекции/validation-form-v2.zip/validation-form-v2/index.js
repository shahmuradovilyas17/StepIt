const form = document.querySelector("form");

const formInputs = document.querySelectorAll("input");


const addErrorInput = (input, text) => {
  input.classList.add("error-input");
  const errorTextElement = document.createElement("span");
  errorTextElement.classList.add("error-input-msg");
  errorTextElement.textContent = text;
  const parentElemntInput = input.parentElement;
  parentElemntInput.append(errorTextElement);
};

const removeErrorInput = (input) => {
  input.classList.remove("error-input");
  const errorTextElement = input.nextElementSibling;
  if (errorTextElement) {
    errorTextElement.remove();
  }
};


form.addEventListener("submit", (e) => {
  e.preventDefault();

  formInputs.forEach((input) => {
    removeErrorInput(input);
  });

  formInputs.forEach((input) => {
    if (input.value === "") {
      addErrorInput(input, "Error not value");
      return;
    }

    if(input.dataset.regExp) {
      if (new RegExp(input.dataset.regExp).test(input.value)) {
        addErrorInput(input, "Error not correct value");
        return;
      }
    }

    if(input.dataset.minLength) {
      if(input.value.length<+input.dataset.minLength) {
        addErrorInput(input, "Error min length");
        return;
      }
    }

    if(input.dataset.maxLength) {
      if(input.value.length>+input.dataset.maxLength) {
        addErrorInput(input, "Error max length");
        return;
      }
    }


    if(input.dataset.regExpEmail) {
      if (!new RegExp(input.dataset.regExpEmail).test(input.value)) {
        addErrorInput(input, "Error not correct email");
        return;
      }
    }
  });
});
