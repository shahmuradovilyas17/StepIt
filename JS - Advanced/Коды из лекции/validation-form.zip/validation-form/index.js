const form = document.querySelector("form");

const formInputs = document.querySelectorAll("input");

const minLengthValidateClass = ["input-name", "input-last-name"];

const maxLengthValidateClass = ["input-name"];

const notNumberInputs = ["input-name", "input-last-name"];

const notNumberRegex = /\d/;

const emailRegExp =
  /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

const addErrorInput = (input, text) => {
  input.classList.add("error-input");
  const errorTextElement = document.createElement("span");
  errorTextElement.classList.add("error-input-msg");
  errorTextElement.textContent = text;
  const parentElemntInput = input.parentElement;
  parentElemntInput.append(errorTextElement);
};

const removeErrorInput = (input) => {
  input.classList.remove("error-input");
  const errorTextElement = input.nextElementSibling;
  if (errorTextElement) {
    errorTextElement.remove();
  }
};

const fnIncludesClassListInArray = (classListArray, classList) => {
  let isIncludeClassName = false;

  classList.forEach((className) => {
    if (classListArray.includes(className)) {
      isIncludeClassName = true;
    }
  });

  return isIncludeClassName;
};

form.addEventListener("submit", (e) => {
  e.preventDefault();

  formInputs.forEach((input) => {
    removeErrorInput(input);
  });

  formInputs.forEach((input) => {
    if (input.value === "") {
      addErrorInput(input, "Error not value");
      return;
    }

    if (fnIncludesClassListInArray(notNumberInputs, input.classList)) {
      if (notNumberRegex.test(input.value)) {
        addErrorInput(input, "Error not correct value");
        return;
      }
    }

    if (fnIncludesClassListInArray(minLengthValidateClass, input.classList)) {
      if (input.value.length < 3) {
        addErrorInput(input, "Error min length");
        return;
      }
    }

    if (fnIncludesClassListInArray(maxLengthValidateClass, input.classList)) {
      if (input.value.length > 10) {
        addErrorInput(input, "Error max length");
        return;
      }
    }

    if (input.classList.contains("input-email")) {
      if (!emailRegExp.test(input.value)) {
        addErrorInput(input, "Error not correct email");
        return;
      }
    }
  });
});
