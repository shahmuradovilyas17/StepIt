const getElementBySelector = (selector) => {
  return document.querySelector(selector);
};

const getElementsBySelector = (selector) => {
  return document.querySelectorAll(selector);
};

const firstName = getElementBySelector("#first-name");

const firstNameValue = firstName.value;

const countrySelect = getElementBySelector("#country-select");

console.log(firstNameValue);

console.dir(countrySelect);

console.dir(countrySelect[countrySelect.selectedIndex].text);

console.dir(countrySelect.value);

const confid = getElementBySelector("#confid");

const ad = getElementBySelector("#ad");

console.log("confid", confid.checked);

console.log("ad", ad.checked);

const gender = getElementsBySelector("[name='gender']");

console.log("🚀 ~ gender:", gender[0].checked);
