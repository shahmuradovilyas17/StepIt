const accordionTabs = document.querySelectorAll(".accordion-tab");
const accordionItems = document.querySelectorAll(".accordion-item");
const accordionContent = document.querySelector(".accordion-content");

accordionTabs.forEach((elem) => {
  elem.addEventListener("click", (event) => {
    let attributeName = elem.getAttribute("data-actab-id");

    accordionTabs.forEach((elem) => {
      elem.classList.remove("accordion-active");
    });
    elem.classList.add("accordion-active");

    const accordionItem = accordionContent.querySelector(
      `[data-actab-id = "${attributeName}"]`
    );

    accordionItems.forEach((elem) => {
      elem.classList.remove("accordion-active");
    });
    accordionItem.classList.add("accordion-active");
  });
});
